"use strict";

var sta,fix=0;
var beg=0;

function addSVG(ite){
	sta.appendChild(ite);
}

function SVGinit(){
	sta=document.getElementById("sta");
	beg=Date.now();
}

function show(){
	for(var i in objs){
		// console.log(objs[i]);
		objs[i].up();
	}
	document.getElementById("ticks").innerHTML="TICKS:"+bt+"s/tick";
	document.getElementById("tot").innerHTML="TOT:"+tot;
	// document.getElementById("totV").innerHTML="TOTV:"+totV;
	if(objs[0]&&!isNaN(objs[0].x))
	document.getElementById("timer").innerHTML="Time:"+(Date.now()-beg)/1000+"s";
	if(crPair!=undefined)
	document.getElementById("pair").innerHTML="Pair:"+crPair.length;
	document.getElementById("mouse").innerHTML="X:"+tox+" Y:"+toy;
	window.requestAnimationFrame(show);
}
