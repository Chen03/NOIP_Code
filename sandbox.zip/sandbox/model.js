"use strict";

var t=0.005;

function object(_x,_y,_r,_m){
	this.svg = document.createElementNS("http://www.w3.org/2000/svg",'circle')
	// this.
	this.r=_r;
	this.m=_m;
	this.color="#000000";
	this.ax=this.ay=0;
	this.p=new vector(_x,_y);
	this.v=new vector();
}

object.prototype.up = function(){
	this.svg.setAttribute("cx",(this.p.x-tox)/t);
	this.svg.setAttribute("cy",(this.p.y-toy)/t);
	this.svg.setAttribute("r",this.r/t);
	this.svg.setAttribute("fill",this.color);
}

class vector{

	constructor(){
		this.x=arguments[0]?arguments[0]:0;
		this.y=arguments[1]?arguments[1]:0;
	}

	get tan(){
		return this.y/this.x;
	}

	get length(){
		return Math.sqrt(Math.pow(this.x,2)+Math.pow(this.y,2));
	}

	static copy(a){
		var tmp=new vector();
		tmp.x=a.x;
		tmp.y=a.y;
		return tmp;
	}

	multi(n){
		this.x*=n;
		this.y*=n;
	}

	static cos(a,b){
		return (a.x*b.x+a.y*b.y)/(a.length*b.length);
	}

	static add(a,b){
		var tmp = new vector();
		tmp.x=a.x+b.x;
		tmp.y=a.y+b.y;
		return tmp;
	}

	static sub(a,b){
		var tmp = new vector();
		tmp.x=a.x-b.x;
		tmp.y=a.y-b.y;
		return tmp;
	}

}