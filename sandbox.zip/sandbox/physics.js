'use strict';

/*
v : m/s
a : m/s^2
g : 9.8m/s^2
F : N
m : kg
tx = m/px
*/
var g = 9.80665;
var G = 6.67e-11;


var tic = 0;
var pre,bt;
var totV;
var tox=0,toy=0;
function flush(){
	totV=0;

	posCou();

	calA();
	bt=(Date.now()-pre)/1000;
	if(bt>0.04)	bt=0.04;
	calV();
	crashProcess();
	move();

	// crashProcess();

	pre=Date.now();
	setTimeout(flush,0);
}

function getDistance(i,j){
	var tmp=Math.sqrt(Math.pow((objs[i].p.x-objs[j].p.x),2)+Math.pow(objs[i].p.y-objs[j].p.y,2));
	// console.log(tmp);
	return tmp;
}

var crPair;
function crashProcess(){
	crPair = new Array();
	calCrash();
	crPair.sort((a,b) => a.di<b.di);
	// var v=vector.sub(objs[],b.v);
	// var e=vector.su
	for(var i in crPair){
		let now=crPair[i];
		if(getDistance(now.a,now.b)>=objs[now.a].r+objs[now.b].r||!objs[now.a].v.length||!objs[now.b].v.length)	continue;
		var vv=vector.sub(objs[now.a].v,objs[now.b].v);
		var e=vector.sub(objs[now.b].p,objs[now.a].p);
		e.multi(1/e.length);
		var v=vector.cos(vv,e)*vv.length;
		if(v<=0)	continue;
		var v1=((objs[now.a].m-objs[now.b].m)/(objs[now.a].m+objs[now.b].m))*v;
		var v2=(2*objs[now.a].m/(objs[now.a].m+objs[now.b].m))*v;
		var oriv=objs[now.b].v.length*vector.cos(objs[now.b].v,e);
		v1+=oriv;v2+=oriv;
		v1-=vector.cos(objs[now.a].v,e)*objs[now.a].v.length;
		v2-=vector.cos(objs[now.b].v,e)*objs[now.b].v.length;
		var e1=vector.copy(e),e2=vector.copy(e);
		e1.multi(v1);
		e2.multi(v2);
		// var vx1=vector.copy(e),vx2=vector.copy(e);
		// vx1.multi(vector.cos(objs[now.a].v,e)*objs[now.a].v.length);
		// vx2.multi(vector.cos(objs[now.b].v,e)*objs[now.b].v.length);
		// objs[now.a].v=vector.sub(objs[])
		objs[now.a].v=vector.add(objs[now.a].v,e1);
		objs[now.b].v=vector.add(objs[now.b].v,e2);
		if(isNaN(objs[now.a].v.x)||isNaN(objs[now.b].v.x))	debugger;
		// console.log(e1);
		// console.log(e2);
		// var v1=v,v2=v;
		// v1.multi((objs[i.a].m-objs[i.b].m)/(objs[i.a].m+objs[i.b].m));
		// v2.multi(2*objs[i.a].m/(objs[i.a].m+objs[i.b].m));
		// var e1=vector.
	}
}

function calCrash(){
	// debugger;
	var di;
	for(var i=0;i<objs.length-1;++i){
		for(var j=i+1;j<objs.length;++j){
			if((di=getDistance(i,j))<objs[i].r+objs[j].r){
				var tmp = new Object();
				tmp.a=i;
				tmp.b=j;
				tmp.di=di;
				crPair.push(tmp);
			}
		}
	}
}

function posCou(){
	if(!objs.length)	return;
	var tx=0,ty=0;
	for(var i in objs){
		tx+=objs[i].p.x;
		ty+=objs[i].p.y;
	}
	tox=tx/objs.length;
	toy=ty/objs.length;
	// debugger;
}

function modify(){
	if(fix!=-1){
		var fx=objs[fix].p.x,fy=objs[fix].p.y;
		for(var i in objs){
			objs[i].p.x-=fx;
			objs[i].p.y-=fy;
		}
	}
}

function move(){
	for(var i in objs){
		objs[i].p.x+=objs[i].v.x*bt;
		objs[i].p.y+=objs[i].v.y*bt;
		if(isNaN(objs[i].p.x))	debugger;
	}
}

function calV(){
	for(var i in objs){
		objs[i].v.x+=objs[i].ax*bt;
		objs[i].v.y+=objs[i].ay*bt;
		totV+=Math.sqrt(Math.pow(Math.abs(objs[i].v.x),2)+Math.pow(Math.abs(objs[i].v.y),2));
		if(isNaN(objs[i].v.x))	debugger;
	}
}

function calA(){
	
	for(var i in objs){
		objs[i].ax=objs[i].ay=0;
		// addGravity(i,0,0,1e9);
		addAllGravity(i);
		if(isNaN(objs[i].ax))	debugger;
	}
}

function addAllGravity(i){
	for(var j in objs){
		if(i===j)	continue;
		addGravity(i,objs[j].p.x,objs[j].p.y,objs[j].m);
	}
}

function addGravity(i,x,y,m){
	if(objs[i].p.x==x&&objs[i].p.y==y)	return;
	var r2=Math.pow((objs[i].p.x-x),2)+Math.pow((objs[i].p.y-y),2);
	var r=Math.sqrt(r2);
	var a=G*m/2*r2;
	objs[i].ax+=(x-objs[i].p.x)/r*a;
	objs[i].ay+=(y-objs[i].p.y)/r*a;
	if(isNaN(objs[i].ax))	debugger;
}
