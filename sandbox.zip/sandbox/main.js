"use strict";
var objs=new Array();

var tot=0;
function addObj(obj){
	++tot;
	objs.push(obj);
	addSVG(obj.svg);
}

function init(){
	SVGinit();
	show();
	flush();
	deb();
}

function deb(){
	// sta.addEventListener("click",clickMouse);
	// sta.addEventListener("mousemove",mouse);
	sta.addEventListener("mouseup",upMouse);
	sta.addEventListener("mousedown",downMouse);
	// document.getElementsByTagName("svg")[0].addEventListener("mouseup",clickMouse);
	// document.getElementsByTagName("svg")
	// for(var i=0;i<100;++i)	addBall();
	// addBalls(1e10,10,1);
	// // addBall(0,0,0,0,1e9,10*t);
	// addBalls(1e9,5,20);
	// addBall(0,0,0,0,1e10,10*t);
	// addObj(a);
}

// var mo = new vector(0,0);
// function moveMouse(e){
// 	mo.x=e.clientX;
// 	mo.y=e.clientY;
// }

function clickMouse(e){
	addBall((e.clientX-500)*t+tox,(400-e.clientY)*t+toy,0,0,1e10,10*t);
	// addBall(0,0,0,0,1e10,10*t);
}

var be = new vector();
function downMouse(e){
	be = new vector(e.clientX,e.clientY);
}

var big=true;
function upMouse(e){
	let ed = new vector(e.clientX,e.clientY)
	let pa = vector.sub(ed,be);
	pa.multi(0.667*t);
	pa.y*=-1;
	console.log(pa);
	big=document.getElementById("big").checked;
	// alert(ed.length*t+"m");
	if(big)	addBall((be.x-500)*t+tox,(400-be.y)*t+toy,pa.x,pa.y,1e10,10*t);
	else	addBall((be.x-500)*t+tox,(400-be.y)*t+toy,pa.x,pa.y,1e9,5*t)
}

function addBalls(m,r,n){
	for(var i=0;i<n;++i)	addRandomBall(m,r);
}

function addRandomBall(m,r){
	addBall(Math.random()*233%0.6-0.3+tox,Math.random()*233%0.6-0.3+toy,Math.random()*100*t-50*t,Math.random()*100*t-50*t,m,r*t);
}

function addBallV(x,y,v,m,r){
	var tes = new object(x,y,r,m);
	tes.v=v
	tes.color="rgb("+Math.random()*2333%255+","+Math.random()*2333%255+","+Math.random()*2333%255+")";
	addObj(tes);
}

function addBall(x,y,vx,vy,m,r){
	var tes = new object(x,y,r,m);
	tes.v.x=vx;
	tes.v.y=vy;
	tes.color="rgb("+Math.random()*2333%255+","+Math.random()*2333%255+","+Math.random()*2333%255+")";
	addObj(tes);
}